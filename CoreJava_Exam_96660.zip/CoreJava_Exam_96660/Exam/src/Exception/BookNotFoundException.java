package Exception;

public class BookNotFoundException extends Exception{
	public BookNotFoundException(String messa) {
		super();
	}

}
