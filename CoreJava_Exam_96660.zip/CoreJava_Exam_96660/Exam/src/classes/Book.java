package classes;
import java.util.*;

public class Book {
	int bookid;
	String title;
	public String author;
	double price;
	boolean isIssued;
	
	public Book() {
		super();
	}

	public Book(int bookid, String title, String author, double price, boolean isIssued) {
		super();
		this.bookid = bookid;
		this.title = title;
		this.author = author;
		this.price = price;
	   this.isIssued = isIssued;
	}


	
	
	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", title=" + title + ", author=" + author + ", price=" + price + ", isIssued="
				+ isIssued + "]";
	}

	public void AddBook(Scanner sc) {
		System.out.println("Enter the Bookid");
		bookid =sc.nextInt();
		System.out.println("Enter the Title");
		title=sc.next();
		System.out.println("Enter the author");
		author=sc.next();
		System.out.println("Enter the Price");
		price =sc.nextDouble();
		System.out.println("Enter the Issued");
		isIssued =sc.nextBoolean();
	
	}

	@Override
	public int hashCode() {
		return Objects.hash(author, bookid, isIssued, price, title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(author, other.author) && bookid == other.bookid && isIssued == other.isIssued
				&& Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price)
				&& Objects.equals(title, other.title);
	}


	
	
	

}
