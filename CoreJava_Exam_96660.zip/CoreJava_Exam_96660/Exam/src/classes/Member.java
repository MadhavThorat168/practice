package classes;
import java.util.*;

public class Member {
int memberid;
String name;
String email;

public Member() {
	super();
}

public Member(int memberid, String name, String email) {
	super();
	this.memberid = memberid;
	this.name = name;
	this.email = email;
}

public void  addmember(Scanner sc) {
	System.out.println("Enter the memberid");
	memberid=sc.nextInt();
	
	System.out.println("Enter the name");
	name=sc.next();
	System.out.println("Enter the email");
	email=sc.next();	
	
}

@Override
public String toString() {
	return "Member [memberid=" + memberid + ", name=" + name + ", email=" + email + "]";
}



}
