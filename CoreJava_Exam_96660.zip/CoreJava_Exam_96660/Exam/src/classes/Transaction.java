package classes;

public class Transaction {
	int transactionid;
	int memberid;
	int bookid;
	
	
	public Transaction() {
		super();
	}


	public Transaction(int transactionid, int memberid, int bookid) {
		super();
		this.transactionid = transactionid;
		this.memberid = memberid;
		this.bookid = bookid;
	}


	@Override
	public String toString() {
		return "Transaction [transactionid=" + transactionid + ", memberid=" + memberid + ", bookid=" + bookid + "]";
	}
	
	

}
