package tester;
import java.util.*;
import classes.*;
import Exception.*;
public class Main {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		List<Book> book= new ArrayList<>();
		
		List<Member> member =new ArrayList<>();
		
		int choice;
		
		do {
			System.out.println("0 : Exit");
			System.out.println("1 : Add New BOOK");
			System.out.println("2 : Add New Member");
			System.out.println("3 : Issue Book to Member");
			System.out.println("4 : Display the issued Book");
			System.out.println("5 : Sort Book By author");
			System.out.println("6 : Display Available Book Only");
			System.out.println("7: Display Book issued to a specific members");
			
			choice =sc.nextInt();
			
			switch(choice) {
			
			case 0:
				System.out.println("Exit");
				break;
				
			case 1:
				Book b1=new Book();
				b1.AddBook(sc);
				book.add(b1);
				break;
				
			case 2: 
				Member m1= new Member();
				m1.addmember(sc);
				member.add(m1);
				break;
				
			case 6:
				for(Book b2:book) {
					
					System.out.println(b2);
				}
				break;
			
			case 5:
				class sortauthor implements Comparator<Book>{

					@Override
					public int compare(Book o1, Book o2) {
						
						return o1.author.compareTo(o2.author);
					}	
			  }
				sortauthor sortauthor=new sortauthor();
				Collections.sort(book,sortauthor);
				for(Book b:book) {
					System.out.println(b);
				}
				break;
			case 7:
//				System.out.println("Enter the book id");
				
//				try {
//					Book b5= new Book();
//					if()
//				
//			}catch(Exception e) {
//				System.out.println
//			}
				
			}
				
		}
			while(choice !=0);
		
}
}
