package single;

import java.util.ArrayList;
import java.util.Arrays;

public class SinglyLinearList {
	static class Node{
		Student data;
		Node next;
		public Node(Student data) {
			this.data=data;
			this.next= null;	
		}
	}
	Node head;
	int count;
	
	public SinglyLinearList() {
		this.head=null;
		this.count=0;
	}
	
	public void AddStudent(Student s) {
		Node nn = new Node (s);
		
		if(head==null) {
			head =nn;
			return;
			
		}Node temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}
		
		temp.next = nn;
		}
	public void displayAll() {
		if (head == null) {
			System.out.println("List is empty");
			return;
		}
		
		Node temp = head;
		while (temp != null) {
	        System.out.print(temp.data);
			temp = temp.next;
		}
	 }
	public void searchByName(String name) throws Exception {
        Node temp = head;

        while (temp != null) {
            if (temp.data.name.equalsIgnoreCase(name)) {
                System.out.println(temp.data);             
                return;
            }
            temp = temp.next;
        }

        throw new Exception("Student not found!");
    }
	
	public void highestmarks() {
		  Node temp = head;
		  int mark=temp.data.getMarks();
	        while (temp!= null) {
	        int	high = temp.data.getMarks();
	             if(high>mark) {
	            	 high=mark;
	            }
	             temp=temp.next;
	           System.out.println(temp.data);
	           return;
	  }        
  }
	public int failstudent() {
		 Node temp = head;
		 int count =0;
		 int mark =40;
	        while (temp != null) {
	        	if(temp.data.getMarks()<mark) {
	        		count++;
	        	}
	        	temp=temp.next;
	        }
		return count;
	        
	}
	
	 public void sortDecendingOrder() {
		 int count =0;
	 String ac[] = new String[50];
		 Node temp = head;
	        while (temp != null) {
	        	String a =temp.data.getName();
	        	ac[0]=a;
	        	temp=temp.next;
	        		Arrays.sort(ac);
	        	
	        	//temp=temp.next;
	        }
	}
}

























