package single;

import java.util.Scanner;

public class SinglyLinkedListMain {

	public static void main(String[] args) throws Exception {
		SinglyLinearList sa= new SinglyLinearList();
		
		Scanner sc = new Scanner (System.in);
		int choice;
		do {
			System.out.println("1: ADD Student");
			System.out.println("2: Display Student");
			System.out.println("3: Display Count of fail student");
			System.out.println("4: Display Highest Marks");
			System.out.println("5: Sort Students in Descending Order by Name");
			System.out.println("6: Search Student Using Name");
			
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter id: ");
				int id = sc.nextInt();
				
				System.out.println("Enter name: ");
				String name = sc.next();
				
				System.out.println("Enter Marks: ");
				int Marks = sc.nextInt();
				
				
				sa.AddStudent(new Student(id, name, Marks));
				break;
				
			case 2:
				sa.displayAll();
				break;
				
			case 3:
				System.out.println( sa.failstudent());
				break;
			case 4:
				sa.highestmarks();
				break;
			case 5:
				sa.sortDecendingOrder();
				break;
			case 6:
				 sc.nextLine(); 
				    System.out.println("Enter name to search: ");
				    String searchName = sc.nextLine();
				    sa.searchByName(searchName);
				    break;
				    
			}
		}while(choice!=0);
		sc.close();

	}

}

