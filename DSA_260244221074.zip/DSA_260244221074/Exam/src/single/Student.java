package single;

public class Student {
	public static String a;
	private int RollNo;
	String name;
	private int Marks;
	
	public Student(int RollNo, String name, int Marks) {
		this.RollNo=RollNo;
		this.name=name;
		this.Marks=Marks;
	}

	public int getRollNo() {
		return RollNo;
	}

	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMarks() {
		return Marks;
	}

	public void setMarks(int marks) {
		Marks = marks;
	}

	@Override
	public String toString() {
		return "Student [RollNo=" + RollNo + ", name=" + name + ", Marks=" + Marks + "]";
	}
	

}
