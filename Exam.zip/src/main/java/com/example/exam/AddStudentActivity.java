package com.example.exam;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddStudentActivity extends AppCompatActivity {
    Toolbar toolBar;
    TextView textSid;
    EditText editName,editEmail,editMobile,editCource;
    Button btn_save_update;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_student);
        toolBar = findViewById(R.id.toolBar);
        textSid = findViewById(R.id.textSid);
        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editMobile = findViewById(R.id.editMobile);
        editCource = findViewById(R.id.editCource);
        btn_save_update = findViewById(R.id.btn_save_update);

        toolBar.setTitle("Add User");

        btn_save_update.setOnClickListener(v->{
            // check for empty fields
            String name = editName.getText().toString();
            String email = editEmail.getText().toString();
            String mobile = editMobile.getText().toString();
            String cource = editCource.getText().toString();
            if(name.equals(""))
                Toast.makeText(this, "Enter the name", Toast.LENGTH_SHORT).show();
            else if(email.equals(""))
                Toast.makeText(this, "Enter the email", Toast.LENGTH_SHORT).show();
            else if(mobile.equals(""))
                Toast.makeText(this, "Enter the mobile", Toast.LENGTH_SHORT).show();
            else if(cource.equals(""))
                Toast.makeText(this, "Enter the city", Toast.LENGTH_SHORT).show();
            else{
                Student std = new Student(name,cource,email,mobile);
                AppDatabase.getInstance(this).getStudentDao().addStudent(std);
                finish();
            }
        });

    }
}