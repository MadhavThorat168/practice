package com.example.exam;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
@Database(version = 1,entities = {Student.class})
public abstract class AppDatabase extends RoomDatabase {

    public abstract StudentDao getStudentDao();
    private static AppDatabase appDatabase = null;
    public static AppDatabase getInstance(Context context){
        if(appDatabase == null)
            appDatabase = Room.databaseBuilder(context, AppDatabase.class,"cpmc_db")
                    .allowMainThreadQueries()
                    .build();
        return appDatabase;
    }
}

