package com.example.exam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Toolbar;


public class DetailStudentActivity extends AppCompatActivity {
    Toolbar toolBar;
    TextView textSid;
    EditText editName,editEmail,editMobile,editCource;
    Button btn_save_update;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_student);
        toolBar = findViewById(R.id.toolBar);
        textSid = findViewById(R.id.textSid);
        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editMobile = findViewById(R.id.editMobile);
        editCource = findViewById(R.id.editCource);
        btn_save_update = findViewById(R.id.btn_save_update);

        Intent intent = getIntent();
        Student std = (Student) intent.getSerializableExtra("std");

        toolBar.setTitle("User Details");
        btn_save_update.setVisibility(View.INVISIBLE);

        // Add the user data in the views
        textSid.setText("User id : "+std.getSid());
        editName.setText(std.getName());
        editEmail.setText(std.getEmail());
        editMobile.setText(std.getMobile());
        editCource.setText(std.getCource());

        editName.setEnabled(false);
        editEmail.setEnabled(false);
        editMobile.setEnabled(false);
        editCource.setEnabled(false);
    }
}



