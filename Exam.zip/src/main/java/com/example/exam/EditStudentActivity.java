package com.example.exam;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditStudentActivity extends AppCompatActivity {
    Toolbar toolBar;
    TextView textSid;
    EditText editName,editEmail,editMobile,editCource;
    Button btn_save_update;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_edit_student);
        toolBar = findViewById(R.id.toolBar);
        textSid = findViewById(R.id.textSid);
        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editMobile = findViewById(R.id.editMobile);
        editCource = findViewById(R.id.editCource);
        btn_save_update = findViewById(R.id.btn_save_update);
        Intent intent = getIntent();
        Student std = (Student)intent.getSerializableExtra("std");
        toolBar.setTitle("Edit Student");
        btn_save_update.setText("Update");

        textSid.setText("Student id : "+std.getSid());
        editName.setText(std.getName());
        editEmail.setText(std.getEmail());
        editMobile.setText(std.getMobile());
        editCource.setText(std.getCource());

        editName.setEnabled(false);
        editEmail.setEnabled(false);

        btn_save_update.setOnClickListener( v->{
            String mobile = editMobile.getText().toString();
            String cource = editCource.getText().toString();
            if(mobile.equals(""))
                Toast.makeText(this, "mobile should not be empty", Toast.LENGTH_SHORT).show();
            else if(cource.equals(""))
                Toast.makeText(this, "cource should not be empty", Toast.LENGTH_SHORT).show();
            else{
                std.setMobile(mobile);
                std.setCource(cource);
                AppDatabase.getInstance(this).getStudentDao().editUser(std);
                finish();
            }
        });
    }
}
