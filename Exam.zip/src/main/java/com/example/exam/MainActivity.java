package com.example.exam;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    ImageView imageadd;
    RecyclerView recyclerView;
    StudentListAdapter studentListAdapter;
    List<Student> studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        imageadd= findViewById(R.id.imageAdd);
        recyclerView=findViewById(R.id.recyclerView);

        studentListAdapter = new StudentListAdapter(this);
        recyclerView.setAdapter(studentListAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this,1));
        imageadd.setOnClickListener(v->{
            Intent intent = new Intent(this, AddStudentActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        studentListAdapter.refreshAdapter();
    }
}














