package com.example.exam;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "students")
public class Student implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int Sid;
    private String Name;
    private String Cource;
    private String Email;
    private String Mobile;

    public Student() {
    }

    public Student(String name, String cource, String email, String mobile) {
        Name = name;
        Cource = cource;
        Email = email;
        Mobile = mobile;
    }

    public int getSid() {
        return Sid;
    }

    public void setSid(int sid) {
        Sid = sid;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCource() {
        return Cource;
    }

    public void setCource(String cource) {
        Cource = cource;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }
}




