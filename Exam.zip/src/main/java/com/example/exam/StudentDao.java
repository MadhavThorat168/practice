package com.example.exam;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;


import java.util.List;

@Dao
public interface StudentDao {
    @Insert
    void addStudent(Student std);

    @Query("SELECT * FROM students")
    List<Student> getAllStudents();

    @Update
    void editUser(Student user);

    @Query("DELETE FROM students WHERE sid=:uid")
    void deleteStudent(int uid);

}
