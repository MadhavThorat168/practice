package com.example.exam;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;

import android.view.ViewGroup;
import android.widget.TextView;



import java.util.List;

public class StudentListAdapter extends  RecyclerView.Adapter<StudentListAdapter.MyViewHolder>{

    Context context;
    List<Student> StudentList;

    public StudentListAdapter(Context context) {
        this.context = context;
        this.StudentList =AppDatabase.getInstance(context).getStudentDao().getAllStudents();
        Log.e("adapter", StudentList.toString() );
    }

    public void refreshAdapter(){
        StudentList = AppDatabase.getInstance(context).getStudentDao().getAllStudents();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.list,null));
    }

    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Student std = StudentList.get(position);
        holder.textSid.setText("Student id : "+std.getSid());
        holder.textName.setText("Student name : "+std.getName());
        holder.textMobile.setText("student mobile : "+std.getMobile());
        holder.itemView.setOnClickListener(v->{
            Intent intent = new Intent(context, DetailStudentActivity.class);
            intent.putExtra("std",std);
            context.startActivity(intent);
        });

        // context menu on recycler view
        holder.itemView.setOnCreateContextMenuListener((menu,view,info)->{
            menu.add("edit").setOnMenuItemClickListener(item -> {
                Intent intent = new Intent(context, EditStudentActivity.class);
                intent.putExtra("std",std);
                context.startActivity(intent);
                return  true;
            });
            menu.add("delete").setOnMenuItemClickListener(item -> {
                AppDatabase.getInstance(context).getStudentDao().deleteStudent(std.getSid());
                refreshAdapter();
                return  true;
            });
        });
    }

    @Override
    public int getItemCount() {
        return StudentList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView textSid,textName,textMobile;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textSid = itemView.findViewById(R.id.textSid);
            textName = itemView.findViewById(R.id.textName);
            textMobile = itemView.findViewById(R.id.textMobile);
        }
    }
}



























































































