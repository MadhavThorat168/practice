package com.example.demo.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entites.Appointment;

public interface AppointmentDao extends JpaRepository<Appointment, Integer> {
	

}
