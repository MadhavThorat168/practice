package com.example.demo.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entites.Doctor;

public interface DoctorDao extends JpaRepository<Doctor, Integer> {

}
