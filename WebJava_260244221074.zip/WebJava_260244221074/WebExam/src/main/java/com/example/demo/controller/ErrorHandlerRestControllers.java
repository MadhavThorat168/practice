
package com.example.demo.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ErrorHandlerRestControllers {

	@ExceptionHandler
	public Resp<?> handleError(Exception e){
		return Resp.error(e.getClass().getName() + ": " + e.getMessage());
	}
}
