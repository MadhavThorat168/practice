package com.example.demo.controller;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dao.DoctorDao;
import com.example.demo.service.DoctorServiceImpl;
import com.example.demoDTO.DoctorDTO;

@RestController
@RequestMapping
public class ServiceController {

		@Autowired
		private DoctorDao doctorDao;
		
		@Autowired
	    private ModelMapper modelMapper;
		@Autowired
		private DoctorServiceImpl service;

		
		 @PostMapping("doct")
		    public Resp<?> addDepartment(@RequestBody DoctorDTO dto) {
		        return Resp.success(service.addDoctor(dto));
		    }
	
			 
			 @DeleteMapping("/doct/{deptId}")
			 public Resp<?> deleteDept(@PathVariable int deptId){
				 service.deleteDoctor(deptId);
				 return Resp.success("Doctor Deleted");
			 }
			 
			 //@PatchMapping("/doct/{id}/")
			 //public Resp<?> UpdateName(@PathVariable int id){
				// service.UpdateDoctor(id);
				 //return Resp.success("Doctor updated");
			 
			 
		}




