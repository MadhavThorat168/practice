package com.example.demo.entites;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="appointment")
public class Appointment {
	@Id
	private int id;
	private String PatientName;
	private Date appointmentsDate;
	@ManyToOne
	@JoinColumn(name="did")
	private Doctor doc;
	
	
	

}
