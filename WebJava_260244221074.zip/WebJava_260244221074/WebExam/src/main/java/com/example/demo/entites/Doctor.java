package com.example.demo.entites;



import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString(exclude="listAppointment")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="doctor")
public class Doctor {
	@Id
	@Column(name="id")
	private int did;
	private String name;
	private String specialization;
	private int experience;
	@OneToMany(mappedBy ="doc")
	private List<Appointment> listAppointment;
	

}




