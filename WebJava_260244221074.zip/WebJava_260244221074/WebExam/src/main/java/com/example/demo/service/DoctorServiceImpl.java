package com.example.demo.service;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.AppointmentDao;
import com.example.demo.Dao.DoctorDao;
import com.example.demo.entites.Doctor;
import com.example.demoDTO.DoctorDTO;


@Service
public class DoctorServiceImpl {
	 
	
		@Autowired
		private AppointmentDao appointmentDao;
		
		@Autowired
		private DoctorDao doctorDao;
		
		@Autowired
		private ModelMapper modelMapper;
		 
		
		 public DoctorDTO  addDoctor(DoctorDTO dto) {
		        Doctor dept = modelMapper.map(dto, Doctor.class);
		        Doctor saved = doctorDao.save(dept);
		        return modelMapper.map(saved, DoctorDTO.class);
		    }
	
			    
			    public void deleteDoctor(int id) {
			    	doctorDao.deleteById(id);
			    }
			    
							 
				 
				 //   public  Doctor updateName(int id, String name) {
				//	 Doctor teacher = DoctorDao.findById(id)
				 //               .orElseThrow(() -> new RuntimeException("Doctor not found"));
				//	 teacher.setName(name);
				//	 return DoctorDao.saveAll(doctorDao);
				 //}
				    
				 

			}





	

