package com.example.demoDTO;

import java.sql.Date;

import com.example.demo.entites.Doctor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class AppointmentDTO {
	private int id;
	private String PatientName;
	private Date appointmentsDate;
	private Doctor doc;

}
