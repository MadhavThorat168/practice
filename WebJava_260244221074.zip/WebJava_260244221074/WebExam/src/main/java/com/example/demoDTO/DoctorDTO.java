package com.example.demoDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DoctorDTO {
	private int id;
	private String name;
	private String specialization;
	private int experience;
	

}
