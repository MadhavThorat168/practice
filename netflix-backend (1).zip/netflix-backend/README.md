# 🎬 Netflix Clone - Spring Boot REST API

A fully functional backend REST API for a Netflix-like video streaming platform.

---

## 🚀 Tech Stack

| Technology         | Version  | Purpose                        |
|--------------------|----------|--------------------------------|
| Spring Boot        | 3.2.5    | Core framework                 |
| Spring Security 6  | —        | JWT-based auth, RBAC           |
| Spring Data JPA    | —        | ORM / database access          |
| MySQL              | 8.0+     | Primary database               |
| Flyway             | —        | Database migrations            |
| jjwt               | 0.12.5   | JWT token generation           |
| Lombok             | —        | Boilerplate reduction          |
| Spring Mail        | —        | Async email notifications      |

---

## ⚙️ Setup Instructions

### Step 1: MySQL Database
```sql
CREATE DATABASE netflix_db;
-- Optional: create dedicated user
CREATE USER 'netflix_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON netflix_db.* TO 'netflix_user'@'localhost';
FLUSH PRIVILEGES;
```

### Step 2: Configure application.properties
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
```
> The database and tables are created automatically by Flyway on first run.

### Step 3: Run in STS
1. Import as Maven project in Spring Tool Suite
2. Right-click project → Run As → Spring Boot App
3. App starts on **http://localhost:8080**

---

## 🔐 Default Admin Account

| Field    | Value                 |
|----------|-----------------------|
| Email    | admin@netflix.com     |
| Password | Admin@123             |
| Role     | ADMIN                 |

---

## 📡 Complete API Reference

**Base URL:** `http://localhost:8080/api/v1`

All responses follow this format:
```json
{
  "success": true,
  "message": "...",
  "data": { ... },
  "timestamp": "2024-01-01T00:00:00"
}
```

---

### 🔑 AUTH APIs

#### Register
```
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "Password123",
  "displayName": "John Doe"
}
```

#### Login
```
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "Password123"
}
```
**Response includes:** `accessToken`, `refreshToken`, `expiresIn`, `user`

#### Refresh Token
```
POST /auth/refresh
Content-Type: application/json

{ "refreshToken": "your_refresh_token_here" }
```

#### Logout
```
POST /auth/logout
Authorization: Bearer <access_token>
```

#### Get Current User
```
GET /auth/me
Authorization: Bearer <access_token>
```

#### Update Profile
```
PUT /auth/profile
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "displayName": "New Name",
  "profilePicture": "https://example.com/pic.jpg"
}
```

#### Change Password
```
PUT /auth/change-password
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "currentPassword": "OldPass123",
  "newPassword": "NewPass456"
}
```

---

### 🎬 VIDEO APIs

#### Browse All Videos
```
GET /videos?page=0&size=20
GET /videos?page=0&size=20&categoryId=1
```

#### Featured Videos (Hero Banner)
```
GET /videos/featured?limit=5
```

#### Trending Videos
```
GET /videos/trending?limit=10
```

#### New Releases
```
GET /videos/new-releases?limit=10
```

#### Search Videos
```
GET /videos/search?q=avengers&page=0&size=20
```

#### Get Video by ID
```
GET /videos/{id}
Authorization: Bearer <token>   (required for premium videos)
```

#### Personalized Recommendations
```
GET /videos/recommendations?limit=10
Authorization: Bearer <access_token>
```

#### Toggle Like/Unlike
```
POST /videos/{id}/like
Authorization: Bearer <access_token>
```

#### Get Liked Videos
```
GET /videos/liked
Authorization: Bearer <access_token>
```

#### Save Watch Progress
```
POST /videos/progress
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "videoId": 1,
  "progressSeconds": 300
}
```

#### Get Watch History
```
GET /videos/history
Authorization: Bearer <access_token>
```

#### Remove from Watch History
```
DELETE /videos/history/{videoId}
Authorization: Bearer <access_token>
```

#### Get Search History
```
GET /videos/search-history
Authorization: Bearer <access_token>
```

#### Clear Search History
```
DELETE /videos/search-history
Authorization: Bearer <access_token>
```

---

### 🏷️ CATEGORY APIs

#### List All Categories
```
GET /categories
```

#### Get Category by ID
```
GET /categories/{id}
```

#### Get Category by Slug
```
GET /categories/slug/action
GET /categories/slug/drama
```

---

### 💳 SUBSCRIPTION APIs

#### View Plans
```
GET /subscriptions/plans
```

#### Get My Subscription
```
GET /subscriptions/status
Authorization: Bearer <access_token>
```

#### Subscribe / Upgrade
```
POST /subscriptions/subscribe
Authorization: Bearer <access_token>
Content-Type: application/json

{ "plan": "STANDARD" }
```
> Valid plans: `FREE`, `STANDARD`, `PREMIUM`

#### Cancel Subscription
```
POST /subscriptions/cancel
Authorization: Bearer <access_token>
```

---

### 🔒 ADMIN APIs (Requires ADMIN role)

#### Platform Statistics
```
GET /admin/stats
Authorization: Bearer <admin_token>
```

#### List All Users
```
GET /admin/users?page=0&size=20&search=john
Authorization: Bearer <admin_token>
```

#### Update User Role
```
PUT /admin/users/{id}/role
Authorization: Bearer <admin_token>
Content-Type: application/json

{ "role": "PREMIUM_USER" }
```
> Valid roles: `USER`, `PREMIUM_USER`, `ADMIN`

#### Enable/Disable User
```
PUT /admin/users/{id}/toggle-status
Authorization: Bearer <admin_token>
```

#### Create Video (URL-based)
```
POST /admin/videos
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "title": "The Dark Knight",
  "description": "Batman faces the Joker...",
  "videoUrl": "https://example.com/dark-knight.mp4",
  "thumbnailUrl": "https://example.com/dk-thumb.jpg",
  "trailerUrl": "https://example.com/dk-trailer.mp4",
  "durationSeconds": 9240,
  "releaseYear": 2008,
  "premium": false,
  "featured": true,
  "categoryId": 1
}
```

#### Update Video
```
PUT /admin/videos/{id}
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "title": "Updated Title",
  "premium": true,
  "featured": false
}
```

#### Delete Video
```
DELETE /admin/videos/{id}
Authorization: Bearer <admin_token>
```

#### Create Category
```
POST /admin/categories
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "name": "Anime",
  "description": "Animated Japanese content",
  "thumbnailUrl": "https://example.com/anime.jpg"
}
```

#### Update Category
```
PUT /admin/categories/{id}
Authorization: Bearer <admin_token>
Content-Type: application/json

{ "name": "Updated Name", "description": "Updated desc" }
```

#### Delete Category
```
DELETE /admin/categories/{id}
Authorization: Bearer <admin_token>
```

---

### 📁 FILE UPLOAD APIs

#### Upload Video File
```
POST /files/upload/video
Authorization: Bearer <admin_token>
Content-Type: multipart/form-data

file=@/path/to/video.mp4
```

#### Upload Thumbnail
```
POST /files/upload/thumbnail
Authorization: Bearer <admin_token>
Content-Type: multipart/form-data

file=@/path/to/thumb.jpg
```

#### Upload Profile Picture
```
POST /files/upload/profile-picture
Authorization: Bearer <access_token>
Content-Type: multipart/form-data

file=@/path/to/picture.jpg
```

---

## 📁 Project Structure

```
src/main/java/com/netflix/backend/
├── NetflixBackendApplication.java       ← Entry point
├── config/
│   ├── AppConfig.java                   ← UserDetailsService, Executor, Static files
│   └── SecurityConfig.java              ← JWT filter chain, CORS, route protection
├── controller/
│   ├── AuthController.java              ← /auth/**
│   ├── VideoController.java             ← /videos/**
│   ├── CategoryController.java          ← /categories/**
│   ├── SubscriptionController.java      ← /subscriptions/**
│   ├── AdminController.java             ← /admin/**
│   └── FileController.java              ← /files/upload/**
├── dto/
│   ├── request/
│   │   ├── AuthRequest.java             ← Register, Login, Refresh, UpdateProfile, ChangePassword
│   │   ├── VideoRequest.java            ← Create, Update, Progress
│   │   └── CategoryRequest.java         ← Create, Update
│   └── response/
│       ├── ApiResponse.java             ← Generic wrapper
│       └── ResponseDTOs.java            ← AuthResponse, UserResponse, VideoResponse, etc.
├── entity/
│   ├── User.java                        ← Implements UserDetails
│   ├── Video.java
│   ├── Category.java
│   ├── Subscription.java
│   ├── WatchHistory.java
│   ├── Like.java
│   └── SearchHistory.java
├── exception/
│   ├── AppException.java                ← Custom exception with HttpStatus
│   └── GlobalExceptionHandler.java      ← @RestControllerAdvice
├── repository/
│   ├── UserRepository.java
│   ├── VideoRepository.java             ← Custom JPQL queries
│   ├── CategoryRepository.java
│   ├── SubscriptionRepository.java
│   ├── WatchHistoryRepository.java
│   ├── LikeRepository.java
│   └── SearchHistoryRepository.java
├── security/jwt/
│   ├── JwtService.java                  ← Token generation & validation
│   └── JwtAuthenticationFilter.java     ← OncePerRequestFilter
└── service/impl/
    ├── AuthService.java
    ├── VideoService.java
    ├── CategoryService.java
    ├── SubscriptionService.java
    ├── AdminService.java
    ├── EmailService.java
    └── FileStorageService.java

src/main/resources/
├── application.properties
└── db/migration/
    └── V1__Initial_Schema.sql           ← Tables + seed data (auto-runs on startup)
```

---

## 🧪 Test Workflow in Postman

1. **Register** → POST `/auth/register`
2. **Login** → POST `/auth/login` → copy `accessToken`
3. Set header: `Authorization: Bearer <accessToken>` for all auth requests
4. **Browse videos** → GET `/videos`
5. **Search** → GET `/videos/search?q=dark`
6. **Like a video** → POST `/videos/1/like`
7. **Save progress** → POST `/videos/progress` with `{"videoId":1,"progressSeconds":120}`
8. **View history** → GET `/videos/history`
9. **Check subscription** → GET `/subscriptions/status`
10. **Upgrade plan** → POST `/subscriptions/subscribe` with `{"plan":"PREMIUM"}`

### Admin Workflow
1. Login as `admin@netflix.com` / `Admin@123`
2. **Create category** → POST `/admin/categories`
3. **Add video** → POST `/admin/videos`
4. **View stats** → GET `/admin/stats`
5. **Manage users** → GET `/admin/users`

---

## ⚠️ Common Issues & Fixes

| Issue | Fix |
|-------|-----|
| `Access Denied` on admin endpoints | Make sure you're logged in as admin and token is set |
| `403 Forbidden` on premium video | Subscribe first: POST `/subscriptions/subscribe` |
| MySQL connection error | Check password in `application.properties` |
| Flyway checksum mismatch | Run `DROP DATABASE netflix_db; CREATE DATABASE netflix_db;` |
| Email sending fails | Set `spring.mail.username/password` or ignore (non-critical) |
