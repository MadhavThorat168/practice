package com.netflix.backend.controller;

import com.netflix.backend.dto.request.CategoryRequest;
import com.netflix.backend.dto.request.VideoRequest;
import com.netflix.backend.dto.response.ApiResponse;
import com.netflix.backend.dto.response.ResponseDTOs.*;
import com.netflix.backend.service.impl.AdminService;
import com.netflix.backend.service.impl.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;
    private final CategoryService categoryService;

    // ═══════════════════════════════════════════════════════════════════════
    //  STATS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * GET /api/v1/admin/stats
     * Returns platform-wide statistics
     */
    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<AdminStatsResponse>> getStats() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getStats()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  USER MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * GET /api/v1/admin/users?page=0&size=20&search=john
     */
    @GetMapping("/users")
    public ResponseEntity<ApiResponse<Page<UserResponse>>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String search) {
        return ResponseEntity.ok(ApiResponse.success(adminService.getAllUsers(page, size, search)));
    }

    /**
     * PUT /api/v1/admin/users/{id}/role
     * Body: { "role": "ADMIN" | "PREMIUM_USER" | "USER" }
     */
    @PutMapping("/users/{id}/role")
    public ResponseEntity<ApiResponse<UserResponse>> updateUserRole(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        String role = body.get("role");
        if (role == null || role.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Role is required. Valid values: USER, PREMIUM_USER, ADMIN"));
        }
        return ResponseEntity.ok(ApiResponse.success("User role updated", adminService.updateUserRole(id, role)));
    }

    /**
     * PUT /api/v1/admin/users/{id}/toggle-status
     * Enable or disable a user account
     */
    @PutMapping("/users/{id}/toggle-status")
    public ResponseEntity<ApiResponse<UserResponse>> toggleUserStatus(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("User status updated", adminService.toggleUserStatus(id)));
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  VIDEO MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * POST /api/v1/admin/videos
     * Create a new video entry (URL-based, no file upload required)
     * Body: {
     *   "title": "Avengers",
     *   "description": "Marvel film",
     *   "videoUrl": "https://example.com/video.mp4",
     *   "thumbnailUrl": "https://example.com/thumb.jpg",
     *   "trailerUrl": "https://example.com/trailer.mp4",
     *   "durationSeconds": 8400,
     *   "releaseYear": 2019,
     *   "premium": false,
     *   "featured": true,
     *   "categoryId": 1
     * }
     */
    @PostMapping("/videos")
    public ResponseEntity<ApiResponse<VideoResponse>> createVideo(
            @Valid @RequestBody VideoRequest.Create request) {
        VideoResponse response = adminService.createVideo(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Video created successfully", response));
    }

    /**
     * PUT /api/v1/admin/videos/{id}
     * Update an existing video (partial update - only send fields you want to change)
     */
    @PutMapping("/videos/{id}")
    public ResponseEntity<ApiResponse<VideoResponse>> updateVideo(
            @PathVariable Long id,
            @RequestBody VideoRequest.Update request) {
        return ResponseEntity.ok(ApiResponse.success("Video updated", adminService.updateVideo(id, request)));
    }

    /**
     * DELETE /api/v1/admin/videos/{id}
     */
    @DeleteMapping("/videos/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteVideo(@PathVariable Long id) {
        adminService.deleteVideo(id);
        return ResponseEntity.ok(ApiResponse.success("Video deleted successfully"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CATEGORY MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * POST /api/v1/admin/categories
     * Body: { "name": "Anime", "description": "Animated Japanese content", "thumbnailUrl": "..." }
     */
    @PostMapping("/categories")
    public ResponseEntity<ApiResponse<CategoryResponse>> createCategory(
            @Valid @RequestBody CategoryRequest.Create request) {
        CategoryResponse response = categoryService.createCategory(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Category created", response));
    }

    /**
     * PUT /api/v1/admin/categories/{id}
     */
    @PutMapping("/categories/{id}")
    public ResponseEntity<ApiResponse<CategoryResponse>> updateCategory(
            @PathVariable Long id,
            @RequestBody CategoryRequest.Update request) {
        return ResponseEntity.ok(ApiResponse.success("Category updated", categoryService.updateCategory(id, request)));
    }

    /**
     * DELETE /api/v1/admin/categories/{id}
     */
    @DeleteMapping("/categories/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteCategory(@PathVariable Long id) {
        categoryService.deleteCategory(id);
        return ResponseEntity.ok(ApiResponse.success("Category deleted"));
    }
}
