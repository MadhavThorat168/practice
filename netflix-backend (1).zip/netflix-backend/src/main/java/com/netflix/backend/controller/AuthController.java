package com.netflix.backend.controller;

import com.netflix.backend.dto.request.AuthRequest;
import com.netflix.backend.dto.response.ApiResponse;
import com.netflix.backend.dto.response.ResponseDTOs.AuthResponse;
import com.netflix.backend.dto.response.ResponseDTOs.UserResponse;
import com.netflix.backend.entity.User;
import com.netflix.backend.service.impl.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    /**
     * POST /api/v1/auth/register
     * Body: { "email", "password", "displayName" }
     */
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(
            @Valid @RequestBody AuthRequest.Register request) {
        AuthResponse response = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Registration successful", response));
    }

    /**
     * POST /api/v1/auth/login
     * Body: { "email", "password" }
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody AuthRequest.Login request) {
        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(ApiResponse.success("Login successful", response));
    }

    /**
     * POST /api/v1/auth/refresh
     * Body: { "refreshToken" }
     */
    @PostMapping("/refresh")
    public ResponseEntity<ApiResponse<AuthResponse>> refreshToken(
            @Valid @RequestBody AuthRequest.RefreshToken request) {
        AuthResponse response = authService.refreshToken(request);
        return ResponseEntity.ok(ApiResponse.success("Token refreshed", response));
    }

    /**
     * POST /api/v1/auth/logout
     * Header: Authorization: Bearer <token>
     */
    @PostMapping("/logout")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> logout(
            @AuthenticationPrincipal User user) {
        authService.logout(user.getEmail());
        return ResponseEntity.ok(ApiResponse.success("Logged out successfully"));
    }

    /**
     * GET /api/v1/auth/me
     * Header: Authorization: Bearer <token>
     */
    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<UserResponse>> getCurrentUser(
            @AuthenticationPrincipal User user) {
        UserResponse response = authService.getCurrentUser(user.getEmail());
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * PUT /api/v1/auth/profile
     * Header: Authorization: Bearer <token>
     * Body: { "displayName", "profilePicture" }
     */
    @PutMapping("/profile")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<UserResponse>> updateProfile(
            @AuthenticationPrincipal User user,
            @RequestBody AuthRequest.UpdateProfile request) {
        UserResponse response = authService.updateProfile(user.getEmail(), request);
        return ResponseEntity.ok(ApiResponse.success("Profile updated", response));
    }

    /**
     * PUT /api/v1/auth/change-password
     * Header: Authorization: Bearer <token>
     * Body: { "currentPassword", "newPassword" }
     */
    @PutMapping("/change-password")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> changePassword(
            @AuthenticationPrincipal User user,
            @Valid @RequestBody AuthRequest.ChangePassword request) {
        authService.changePassword(user.getEmail(), request);
        return ResponseEntity.ok(ApiResponse.success("Password changed successfully. Please login again."));
    }
}
