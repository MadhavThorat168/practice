package com.netflix.backend.controller;

import com.netflix.backend.dto.response.ApiResponse;
import com.netflix.backend.service.impl.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/files")
@RequiredArgsConstructor
public class FileController {

    private final FileStorageService fileStorageService;

    /**
     * POST /api/v1/files/upload/video
     * Admin only - upload a video file, returns the URL
     */
    @PostMapping("/upload/video")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, String>>> uploadVideo(
            @RequestParam("file") MultipartFile file) {
        String url = fileStorageService.storeVideo(file);
        return ResponseEntity.ok(ApiResponse.success("Video uploaded", Map.of("url", url)));
    }

    /**
     * POST /api/v1/files/upload/thumbnail
     * Admin only - upload a thumbnail image, returns the URL
     */
    @PostMapping("/upload/thumbnail")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, String>>> uploadThumbnail(
            @RequestParam("file") MultipartFile file) {
        String url = fileStorageService.storeThumbnail(file);
        return ResponseEntity.ok(ApiResponse.success("Thumbnail uploaded", Map.of("url", url)));
    }

    /**
     * POST /api/v1/files/upload/profile-picture
     * Auth Required - upload profile picture for current user
     */
    @PostMapping("/upload/profile-picture")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Map<String, String>>> uploadProfilePicture(
            @RequestParam("file") MultipartFile file) {
        String url = fileStorageService.storeProfilePicture(file);
        return ResponseEntity.ok(ApiResponse.success("Profile picture uploaded", Map.of("url", url)));
    }
}
