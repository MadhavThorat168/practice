package com.netflix.backend.controller;

import com.netflix.backend.dto.response.ApiResponse;
import com.netflix.backend.dto.response.ResponseDTOs.PlanInfo;
import com.netflix.backend.dto.response.ResponseDTOs.SubscriptionResponse;
import com.netflix.backend.entity.User;
import com.netflix.backend.service.impl.SubscriptionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/subscriptions")
@RequiredArgsConstructor
public class SubscriptionController {

    private final SubscriptionService subscriptionService;

    /**
     * GET /api/v1/subscriptions/plans
     * Public - view all subscription plans
     */
    @GetMapping("/plans")
    public ResponseEntity<ApiResponse<List<PlanInfo>>> getPlans() {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getAvailablePlans()));
    }

    /**
     * GET /api/v1/subscriptions/status
     * Auth Required - get current user's subscription
     */
    @GetMapping("/status")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<SubscriptionResponse>> getStatus(
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(ApiResponse.success(subscriptionService.getStatus(user.getEmail())));
    }

    /**
     * POST /api/v1/subscriptions/subscribe
     * Auth Required - subscribe or upgrade plan
     * Body: { "plan": "STANDARD" }
     */
    @PostMapping("/subscribe")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<SubscriptionResponse>> subscribe(
            @AuthenticationPrincipal User user,
            @RequestBody Map<String, String> body) {
        String plan = body.get("plan");
        if (plan == null || plan.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Plan is required. Valid values: FREE, STANDARD, PREMIUM"));
        }
        SubscriptionResponse response = subscriptionService.subscribe(user.getEmail(), plan);
        return ResponseEntity.ok(ApiResponse.success("Subscription updated to " + plan, response));
    }

    /**
     * POST /api/v1/subscriptions/cancel
     * Auth Required - cancel current subscription
     */
    @PostMapping("/cancel")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<SubscriptionResponse>> cancel(
            @AuthenticationPrincipal User user) {
        SubscriptionResponse response = subscriptionService.cancel(user.getEmail());
        return ResponseEntity.ok(ApiResponse.success("Subscription cancelled successfully", response));
    }
}
