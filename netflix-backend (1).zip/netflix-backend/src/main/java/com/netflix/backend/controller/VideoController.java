package com.netflix.backend.controller;

import com.netflix.backend.dto.request.VideoRequest;
import com.netflix.backend.dto.response.ApiResponse;
import com.netflix.backend.dto.response.ResponseDTOs.*;
import com.netflix.backend.entity.User;
import com.netflix.backend.service.impl.VideoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/videos")
@RequiredArgsConstructor
public class VideoController {

    private final VideoService videoService;

    /**
     * GET /api/v1/videos?page=0&size=20&categoryId=1
     * Public - browse all videos paginated, optionally filtered by category
     */
    @GetMapping
    public ResponseEntity<ApiResponse<Page<VideoResponse>>> getAllVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) Long categoryId) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getAllVideos(page, size, categoryId)));
    }

    /**
     * GET /api/v1/videos/featured?limit=5
     * Public - get featured/hero videos
     */
    @GetMapping("/featured")
    public ResponseEntity<ApiResponse<List<VideoResponse>>> getFeaturedVideos(
            @RequestParam(defaultValue = "5") int limit) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getFeaturedVideos(limit)));
    }

    /**
     * GET /api/v1/videos/trending?limit=10
     * Public - get trending videos by view count
     */
    @GetMapping("/trending")
    public ResponseEntity<ApiResponse<List<VideoResponse>>> getTrendingVideos(
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getTrendingVideos(limit)));
    }

    /**
     * GET /api/v1/videos/new-releases?limit=10
     * Public - get latest uploaded videos
     */
    @GetMapping("/new-releases")
    public ResponseEntity<ApiResponse<List<VideoResponse>>> getNewReleases(
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getNewReleases(limit)));
    }

    /**
     * GET /api/v1/videos/search?q=avengers&page=0&size=20
     * Public - search videos by title/description
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<Page<VideoResponse>>> searchVideos(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal User user) {
        String email = (user != null) ? user.getEmail() : null;
        return ResponseEntity.ok(ApiResponse.success(videoService.searchVideos(q, page, size, email)));
    }

    /**
     * GET /api/v1/videos/recommendations?limit=10
     * Auth Required - personalized recommendations based on watch history
     */
    @GetMapping("/recommendations")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<VideoResponse>>> getRecommendations(
            @AuthenticationPrincipal User user,
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getRecommendations(user.getEmail(), limit)));
    }

    /**
     * GET /api/v1/videos/{id}
     * Public for free content, Auth required for premium content
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<VideoResponse>> getVideoById(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        String email = (user != null) ? user.getEmail() : null;
        VideoResponse video = videoService.getVideoById(id, email);
        // Increment view count async
        videoService.incrementViewCount(id);
        return ResponseEntity.ok(ApiResponse.success(video));
    }

    /**
     * GET /api/v1/videos/liked
     * Auth Required - get all liked videos for current user
     */
    @GetMapping("/liked")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<VideoResponse>>> getLikedVideos(
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getLikedVideos(user.getEmail())));
    }

    /**
     * POST /api/v1/videos/{id}/like
     * Auth Required - toggle like/unlike on a video
     */
    @PostMapping("/{id}/like")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Map<String, Object>>> toggleLike(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        boolean isLiked = videoService.toggleLike(id, user.getEmail());
        String msg = isLiked ? "Video liked" : "Video unliked";
        return ResponseEntity.ok(ApiResponse.success(msg, Map.of("liked", isLiked, "videoId", id)));
    }

    /**
     * POST /api/v1/videos/progress
     * Auth Required - save watch progress
     * Body: { "videoId": 1, "progressSeconds": 300 }
     */
    @PostMapping("/progress")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> saveProgress(
            @Valid @RequestBody VideoRequest.Progress request,
            @AuthenticationPrincipal User user) {
        videoService.saveWatchProgress(request, user.getEmail());
        return ResponseEntity.ok(ApiResponse.success("Watch progress saved"));
    }

    /**
     * GET /api/v1/videos/history
     * Auth Required - get watch history with progress
     */
    @GetMapping("/history")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<WatchHistoryResponse>>> getWatchHistory(
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getWatchHistory(user.getEmail())));
    }

    /**
     * DELETE /api/v1/videos/history/{videoId}
     * Auth Required - remove a video from watch history
     */
    @DeleteMapping("/history/{videoId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> removeFromHistory(
            @PathVariable Long videoId,
            @AuthenticationPrincipal User user) {
        videoService.removeFromHistory(videoId, user.getEmail());
        return ResponseEntity.ok(ApiResponse.success("Removed from watch history"));
    }

    /**
     * GET /api/v1/videos/search-history
     * Auth Required - get search history
     */
    @GetMapping("/search-history")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<SearchHistoryResponse>>> getSearchHistory(
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(ApiResponse.success(videoService.getSearchHistory(user.getEmail())));
    }

    /**
     * DELETE /api/v1/videos/search-history
     * Auth Required - clear all search history
     */
    @DeleteMapping("/search-history")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> clearSearchHistory(
            @AuthenticationPrincipal User user) {
        videoService.clearSearchHistory(user.getEmail());
        return ResponseEntity.ok(ApiResponse.success("Search history cleared"));
    }
}
