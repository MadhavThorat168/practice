package com.netflix.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

public class CategoryRequest {

    @Data
    public static class Create {
        @NotBlank(message = "Category name is required")
        private String name;

        private String description;
        private String thumbnailUrl;
    }

    @Data
    public static class Update {
        private String name;
        private String description;
        private String thumbnailUrl;
    }
}
