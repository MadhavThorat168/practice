package com.netflix.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

public class VideoRequest {

    @Data
    public static class Create {
        @NotBlank(message = "Title is required")
        private String title;

        private String description;

        @NotBlank(message = "Video URL is required")
        private String videoUrl;

        private String thumbnailUrl;
        private String trailerUrl;

        @Positive
        private Integer durationSeconds;

        private Integer releaseYear;

        private boolean premium = false;
        private boolean featured = false;

        @NotNull(message = "Category ID is required")
        private Long categoryId;
    }

    @Data
    public static class Update {
        private String title;
        private String description;
        private String videoUrl;
        private String thumbnailUrl;
        private String trailerUrl;
        private Integer durationSeconds;
        private Integer releaseYear;
        private Boolean premium;
        private Boolean featured;
        private Long categoryId;
    }

    @Data
    public static class Progress {
        @NotNull(message = "Video ID is required")
        private Long videoId;

        @NotNull(message = "Progress seconds is required")
        private Integer progressSeconds;
    }
}
