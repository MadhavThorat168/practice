package com.netflix.backend.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.netflix.backend.entity.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

public class ResponseDTOs {

    // ── Auth ──────────────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AuthResponse {
        private String accessToken;
        private String refreshToken;
        private String tokenType;
        private Long expiresIn;
        private UserResponse user;
    }

    // ── User ──────────────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class UserResponse {
        private Long id;
        private String email;
        private String displayName;
        private String profilePicture;
        private String role;
        private boolean enabled;
        private LocalDateTime createdAt;

        public static UserResponse from(User user) {
            return UserResponse.builder()
                    .id(user.getId())
                    .email(user.getEmail())
                    .displayName(user.getDisplayName())
                    .profilePicture(user.getProfilePicture())
                    .role(user.getRole().name())
                    .enabled(user.isEnabled())
                    .createdAt(user.getCreatedAt())
                    .build();
        }
    }

    // ── Category ──────────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CategoryResponse {
        private Long id;
        private String name;
        private String slug;
        private String description;
        private String thumbnailUrl;
        private LocalDateTime createdAt;

        public static CategoryResponse from(Category c) {
            return CategoryResponse.builder()
                    .id(c.getId())
                    .name(c.getName())
                    .slug(c.getSlug())
                    .description(c.getDescription())
                    .thumbnailUrl(c.getThumbnailUrl())
                    .createdAt(c.getCreatedAt())
                    .build();
        }
    }

    // ── Video ─────────────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class VideoResponse {
        private Long id;
        private String title;
        private String description;
        private String videoUrl;
        private String thumbnailUrl;
        private String trailerUrl;
        private Integer durationSeconds;
        private Integer releaseYear;
        private boolean premium;
        private boolean featured;
        private Long viewCount;
        private Long likeCount;
        private CategoryResponse category;
        private Boolean liked;
        private Integer watchProgress;
        private boolean watched;
        private LocalDateTime createdAt;

        public static VideoResponse from(Video v) {
            return VideoResponse.builder()
                    .id(v.getId())
                    .title(v.getTitle())
                    .description(v.getDescription())
                    .videoUrl(v.getVideoUrl())
                    .thumbnailUrl(v.getThumbnailUrl())
                    .trailerUrl(v.getTrailerUrl())
                    .durationSeconds(v.getDurationSeconds())
                    .releaseYear(v.getReleaseYear())
                    .premium(v.isPremium())
                    .featured(v.isFeatured())
                    .viewCount(v.getViewCount())
                    .category(CategoryResponse.from(v.getCategory()))
                    .createdAt(v.getCreatedAt())
                    .build();
        }
    }

    // ── Subscription ──────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SubscriptionResponse {
        private Long id;
        private String plan;
        private String status;
        private LocalDateTime startDate;
        private LocalDateTime endDate;
        private LocalDateTime createdAt;

        public static SubscriptionResponse from(Subscription s) {
            return SubscriptionResponse.builder()
                    .id(s.getId())
                    .plan(s.getPlan().name())
                    .status(s.getStatus().name())
                    .startDate(s.getStartDate())
                    .endDate(s.getEndDate())
                    .createdAt(s.getCreatedAt())
                    .build();
        }
    }

    // ── Watch History ─────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class WatchHistoryResponse {
        private Long id;
        private Long videoId;
        private String title;
        private String thumbnailUrl;
        private Integer progressSeconds;
        private Integer durationSeconds;
        private boolean completed;
        private Integer progressPercentage;
        private LocalDateTime watchedAt;
    }

    // ── Admin Stats ───────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AdminStatsResponse {
        private long totalUsers;
        private long totalVideos;
        private long totalCategories;
        private long premiumSubscribers;
        private long totalViews;
        private long totalLikes;
    }

    // ── Plan Info ─────────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PlanInfo {
        private String name;
        private int priceInr;
        private String description;
        private List<String> features;
        private boolean popular;
    }

    // ── Search History ────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SearchHistoryResponse {
        private Long id;
        private String query;
        private LocalDateTime searchedAt;
    }
}
