package com.netflix.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "watch_history",
        uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "video_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WatchHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "video_id", nullable = false)
    private Video video;

    @Column(name = "progress_seconds")
    @Builder.Default
    private Integer progressSeconds = 0;

    @Builder.Default
    private boolean completed = false;

    @Column(name = "watched_at")
    private LocalDateTime watchedAt;

    @PrePersist
    @PreUpdate
    protected void onSave() {
        watchedAt = LocalDateTime.now();
    }
}
