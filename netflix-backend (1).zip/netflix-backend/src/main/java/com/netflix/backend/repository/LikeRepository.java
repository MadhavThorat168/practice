package com.netflix.backend.repository;

import com.netflix.backend.entity.Like;
import com.netflix.backend.entity.Video;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LikeRepository extends JpaRepository<Like, Long> {

    boolean existsByUserIdAndVideoId(Long userId, Long videoId);

    Optional<Like> findByUserIdAndVideoId(Long userId, Long videoId);

    long countByVideoId(Long videoId);

    @Query("SELECT l.video FROM Like l WHERE l.user.id = :userId ORDER BY l.createdAt DESC")
    List<Video> findLikedVideosByUserId(@Param("userId") Long userId, Pageable pageable);
}
