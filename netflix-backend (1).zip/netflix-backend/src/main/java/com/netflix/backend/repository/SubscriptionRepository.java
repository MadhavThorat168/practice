package com.netflix.backend.repository;

import com.netflix.backend.entity.Subscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    Optional<Subscription> findByUserId(Long userId);

    long countByPlanNotAndStatusIs(Subscription.Plan plan, Subscription.Status status);

    // Find expired subscriptions to auto-expire them
    @Query("SELECT s FROM Subscription s WHERE s.status = 'ACTIVE' AND s.endDate IS NOT NULL AND s.endDate < :now")
    List<Subscription> findExpiredSubscriptions(LocalDateTime now);
}
