package com.netflix.backend.repository;

import com.netflix.backend.entity.Video;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VideoRepository extends JpaRepository<Video, Long> {

    // Browse by category
    Page<Video> findByCategoryId(Long categoryId, Pageable pageable);

    // Featured videos
    @Query("SELECT v FROM Video v WHERE v.featured = true ORDER BY v.createdAt DESC")
    List<Video> findFeaturedVideos(Pageable pageable);

    // Trending by view count
    @Query("SELECT v FROM Video v ORDER BY v.viewCount DESC")
    List<Video> findTrendingVideos(Pageable pageable);

    // New releases
    @Query("SELECT v FROM Video v ORDER BY v.createdAt DESC")
    List<Video> findNewReleases(Pageable pageable);

    // Search by title or description
    @Query("SELECT v FROM Video v WHERE " +
           "LOWER(v.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(v.description) LIKE LOWER(CONCAT('%', :query, '%'))")
    Page<Video> searchVideos(@Param("query") String query, Pageable pageable);

    // Personalized recommendations: videos from genres user has watched, excluding already-watched
    @Query("SELECT DISTINCT v FROM Video v " +
           "WHERE v.category.id IN (" +
           "    SELECT DISTINCT wh.video.category.id FROM WatchHistory wh WHERE wh.user.id = :userId" +
           ") " +
           "AND v.id NOT IN (" +
           "    SELECT wh2.video.id FROM WatchHistory wh2 WHERE wh2.user.id = :userId" +
           ") " +
           "ORDER BY v.viewCount DESC")
    List<Video> findRecommendations(@Param("userId") Long userId, Pageable pageable);

    // Increment view count atomically
    @Modifying
    @Query("UPDATE Video v SET v.viewCount = v.viewCount + 1 WHERE v.id = :id")
    void incrementViewCount(@Param("id") Long id);

    // Premium videos only
    Page<Video> findByPremiumTrue(Pageable pageable);

    // By category slug
    @Query("SELECT v FROM Video v WHERE v.category.slug = :slug")
    Page<Video> findByCategorySlug(@Param("slug") String slug, Pageable pageable);
}
