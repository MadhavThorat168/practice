package com.netflix.backend.repository;

import com.netflix.backend.entity.WatchHistory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WatchHistoryRepository extends JpaRepository<WatchHistory, Long> {

    Optional<WatchHistory> findByUserIdAndVideoId(Long userId, Long videoId);

    @Query("SELECT wh FROM WatchHistory wh WHERE wh.user.id = :userId ORDER BY wh.watchedAt DESC")
    List<WatchHistory> findByUserIdOrderByWatchedAtDesc(@Param("userId") Long userId, Pageable pageable);

    boolean existsByUserIdAndVideoId(Long userId, Long videoId);

    void deleteByUserIdAndVideoId(Long userId, Long videoId);
}
