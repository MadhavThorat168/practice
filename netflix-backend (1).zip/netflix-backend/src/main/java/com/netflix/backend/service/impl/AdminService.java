package com.netflix.backend.service.impl;

import com.netflix.backend.dto.request.VideoRequest;
import com.netflix.backend.dto.response.ResponseDTOs.*;
import com.netflix.backend.entity.*;
import com.netflix.backend.exception.AppException;
import com.netflix.backend.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AdminService {

    private final UserRepository userRepository;
    private final VideoRepository videoRepository;
    private final CategoryRepository categoryRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final LikeRepository likeRepository;

    // ── Stats ─────────────────────────────────────────────────────────────

    public AdminStatsResponse getStats() {
        long premiumSubscribers = subscriptionRepository
                .countByPlanNotAndStatusIs(Subscription.Plan.FREE, Subscription.Status.ACTIVE);

        long totalViews = videoRepository.findAll()
                .stream()
                .mapToLong(v -> v.getViewCount() != null ? v.getViewCount() : 0L)
                .sum();

        long totalLikes = likeRepository.count();

        return AdminStatsResponse.builder()
                .totalUsers(userRepository.count())
                .totalVideos(videoRepository.count())
                .totalCategories(categoryRepository.count())
                .premiumSubscribers(premiumSubscribers)
                .totalViews(totalViews)
                .totalLikes(totalLikes)
                .build();
    }

    // ── User Management ───────────────────────────────────────────────────

    public Page<UserResponse> getAllUsers(int page, int size, String search) {
        PageRequest pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<User> users;

        if (search != null && !search.isBlank()) {
            users = userRepository.findByDisplayNameContainingIgnoreCaseOrEmailContainingIgnoreCase(
                    search, search, pageable);
        } else {
            users = userRepository.findAll(pageable);
        }

        return users.map(UserResponse::from);
    }

    @Transactional
    public UserResponse updateUserRole(Long userId, String roleName) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        User.Role role;
        try {
            role = User.Role.valueOf(roleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new AppException("Invalid role: " + roleName + ". Valid: USER, PREMIUM_USER, ADMIN", HttpStatus.BAD_REQUEST);
        }

        user.setRole(role);
        userRepository.save(user);
        log.info("Admin updated user {} role to {}", userId, role);
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse toggleUserStatus(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        user.setEnabled(!user.isEnabled());
        userRepository.save(user);
        return UserResponse.from(user);
    }

    // ── Video Management ──────────────────────────────────────────────────

    @Transactional
    public VideoResponse createVideo(VideoRequest.Create request) {
        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new AppException("Category not found with id: " + request.getCategoryId(), HttpStatus.NOT_FOUND));

        Video video = Video.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .videoUrl(request.getVideoUrl())
                .thumbnailUrl(request.getThumbnailUrl())
                .trailerUrl(request.getTrailerUrl())
                .durationSeconds(request.getDurationSeconds() != null ? request.getDurationSeconds() : 0)
                .releaseYear(request.getReleaseYear())
                .premium(request.isPremium())
                .featured(request.isFeatured())
                .category(category)
                .viewCount(0L)
                .build();

        Video saved = videoRepository.save(video);
        log.info("Admin created video: {} (id={})", saved.getTitle(), saved.getId());
        return VideoResponse.from(saved);
    }

    @Transactional
    public VideoResponse updateVideo(Long videoId, VideoRequest.Update request) {
        Video video = videoRepository.findById(videoId)
                .orElseThrow(() -> new AppException("Video not found", HttpStatus.NOT_FOUND));

        if (request.getTitle() != null && !request.getTitle().isBlank()) {
            video.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            video.setDescription(request.getDescription());
        }
        if (request.getVideoUrl() != null && !request.getVideoUrl().isBlank()) {
            video.setVideoUrl(request.getVideoUrl());
        }
        if (request.getThumbnailUrl() != null) {
            video.setThumbnailUrl(request.getThumbnailUrl());
        }
        if (request.getTrailerUrl() != null) {
            video.setTrailerUrl(request.getTrailerUrl());
        }
        if (request.getDurationSeconds() != null) {
            video.setDurationSeconds(request.getDurationSeconds());
        }
        if (request.getReleaseYear() != null) {
            video.setReleaseYear(request.getReleaseYear());
        }
        if (request.getPremium() != null) {
            video.setPremium(request.getPremium());
        }
        if (request.getFeatured() != null) {
            video.setFeatured(request.getFeatured());
        }
        if (request.getCategoryId() != null) {
            Category category = categoryRepository.findById(request.getCategoryId())
                    .orElseThrow(() -> new AppException("Category not found", HttpStatus.NOT_FOUND));
            video.setCategory(category);
        }

        Video saved = videoRepository.save(video);
        log.info("Admin updated video: {}", saved.getId());
        return VideoResponse.from(saved);
    }

    @Transactional
    public void deleteVideo(Long videoId) {
        Video video = videoRepository.findById(videoId)
                .orElseThrow(() -> new AppException("Video not found with id: " + videoId, HttpStatus.NOT_FOUND));
        videoRepository.delete(video);
        log.info("Admin deleted video: {}", videoId);
    }
}
