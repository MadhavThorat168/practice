package com.netflix.backend.service.impl;

import com.netflix.backend.dto.request.AuthRequest;
import com.netflix.backend.dto.response.ResponseDTOs.AuthResponse;
import com.netflix.backend.dto.response.ResponseDTOs.UserResponse;
import com.netflix.backend.entity.Subscription;
import com.netflix.backend.entity.User;
import com.netflix.backend.exception.AppException;
import com.netflix.backend.repository.SubscriptionRepository;
import com.netflix.backend.repository.UserRepository;
import com.netflix.backend.security.jwt.JwtService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final EmailService emailService;

    // ── Register ──────────────────────────────────────────────────────────

    @Transactional
    public AuthResponse register(AuthRequest.Register request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AppException("Email is already registered", HttpStatus.CONFLICT);
        }

        User user = User.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .displayName(request.getDisplayName())
                .role(User.Role.USER)
                .build();

        userRepository.save(user);
        log.info("New user registered: {}", user.getEmail());

        // Create default FREE subscription
        Subscription subscription = Subscription.builder()
                .user(user)
                .plan(Subscription.Plan.FREE)
                .status(Subscription.Status.ACTIVE)
                .build();
        subscriptionRepository.save(subscription);

        // Send welcome email (async, non-blocking)
        emailService.sendWelcomeEmail(user.getEmail(), user.getDisplayName());

        return buildAuthResponse(user);
    }

    // ── Login ─────────────────────────────────────────────────────────────

    @Transactional
    public AuthResponse login(AuthRequest.Login request) {
        // Spring Security handles bad credentials with BadCredentialsException
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        log.info("User logged in: {}", user.getEmail());
        return buildAuthResponse(user);
    }

    // ── Refresh Token ─────────────────────────────────────────────────────

    @Transactional
    public AuthResponse refreshToken(AuthRequest.RefreshToken request) {
        User user = userRepository.findByRefreshToken(request.getRefreshToken())
                .orElseThrow(() -> new AppException("Invalid or expired refresh token", HttpStatus.UNAUTHORIZED));

        if (!jwtService.isTokenValid(request.getRefreshToken(), user)) {
            user.setRefreshToken(null);
            userRepository.save(user);
            throw new AppException("Refresh token has expired. Please login again.", HttpStatus.UNAUTHORIZED);
        }

        return buildAuthResponse(user);
    }

    // ── Logout ────────────────────────────────────────────────────────────

    @Transactional
    public void logout(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        user.setRefreshToken(null);
        userRepository.save(user);
        log.info("User logged out: {}", email);
    }

    // ── Get Current User ──────────────────────────────────────────────────

    public UserResponse getCurrentUser(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        return UserResponse.from(user);
    }

    // ── Update Profile ────────────────────────────────────────────────────

    @Transactional
    public UserResponse updateProfile(String email, AuthRequest.UpdateProfile request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        if (request.getDisplayName() != null && !request.getDisplayName().isBlank()) {
            user.setDisplayName(request.getDisplayName());
        }
        if (request.getProfilePicture() != null) {
            user.setProfilePicture(request.getProfilePicture());
        }

        userRepository.save(user);
        return UserResponse.from(user);
    }

    // ── Change Password ───────────────────────────────────────────────────

    @Transactional
    public void changePassword(String email, AuthRequest.ChangePassword request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw new AppException("Current password is incorrect", HttpStatus.BAD_REQUEST);
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setRefreshToken(null); // Invalidate all sessions
        userRepository.save(user);
        log.info("Password changed for user: {}", email);
    }

    // ── Private: Build Auth Response ──────────────────────────────────────

    private AuthResponse buildAuthResponse(User user) {
        String accessToken = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);

        user.setRefreshToken(refreshToken);
        userRepository.save(user);

        return AuthResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .expiresIn(jwtService.getAccessTokenExpirationMs())
                .user(UserResponse.from(user))
                .build();
    }
}
