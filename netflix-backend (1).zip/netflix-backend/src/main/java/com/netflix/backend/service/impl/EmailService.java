package com.netflix.backend.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Async("taskExecutor")
    public void sendWelcomeEmail(String toEmail, String displayName) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("Welcome to Netflix Clone!");
            message.setText(
                    "Hi " + displayName + ",\n\n" +
                    "Welcome to Netflix Clone! Your account has been created successfully.\n\n" +
                    "You can now:\n" +
                    "- Browse thousands of movies and series\n" +
                    "- Track your watch history\n" +
                    "- Get personalized recommendations\n" +
                    "- Upgrade to Premium for exclusive content\n\n" +
                    "Happy Watching!\n" +
                    "The Netflix Clone Team"
            );
            mailSender.send(message);
            log.info("Welcome email sent to {}", toEmail);
        } catch (Exception e) {
            // Non-critical - log and continue
            log.warn("Failed to send welcome email to {}: {}", toEmail, e.getMessage());
        }
    }

    @Async("taskExecutor")
    public void sendSubscriptionConfirmation(String toEmail, String displayName, String plan) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("Subscription Confirmed - " + plan + " Plan");
            message.setText(
                    "Hi " + displayName + ",\n\n" +
                    "Your subscription to the " + plan + " plan has been confirmed!\n\n" +
                    "You now have access to all " + plan + " features.\n\n" +
                    "Thank you for subscribing!\n" +
                    "The Netflix Clone Team"
            );
            mailSender.send(message);
        } catch (Exception e) {
            log.warn("Failed to send subscription email to {}: {}", toEmail, e.getMessage());
        }
    }
}
