package com.netflix.backend.service.impl;

import com.netflix.backend.exception.AppException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class FileStorageService {

    @Value("${app.storage.upload-dir}")
    private String uploadDir;

    @Value("${app.storage.base-url}")
    private String baseUrl;

    private static final List<String> ALLOWED_VIDEO_TYPES =
            Arrays.asList("video/mp4", "video/webm", "video/ogg", "application/x-mpegURL", "video/x-msvideo");

    private static final List<String> ALLOWED_IMAGE_TYPES =
            Arrays.asList("image/jpeg", "image/png", "image/webp", "image/gif");

    public String storeVideo(MultipartFile file) {
        validateFile(file, ALLOWED_VIDEO_TYPES, "video");
        return store(file, "videos");
    }

    public String storeThumbnail(MultipartFile file) {
        validateFile(file, ALLOWED_IMAGE_TYPES, "image");
        return store(file, "thumbnails");
    }

    public String storeProfilePicture(MultipartFile file) {
        validateFile(file, ALLOWED_IMAGE_TYPES, "image");
        return store(file, "profiles");
    }

    private String store(MultipartFile file, String subfolder) {
        try {
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf('.'));
            }

            String filename = UUID.randomUUID().toString() + extension;
            Path destinationDir = Paths.get(uploadDir, subfolder);
            Files.createDirectories(destinationDir);

            Path destination = destinationDir.resolve(filename);
            Files.copy(file.getInputStream(), destination, StandardCopyOption.REPLACE_EXISTING);

            String url = baseUrl + "/" + subfolder + "/" + filename;
            log.info("Stored file: {}", url);
            return url;
        } catch (IOException e) {
            log.error("Failed to store file: {}", e.getMessage());
            throw new AppException("Failed to store file: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void validateFile(MultipartFile file, List<String> allowedTypes, String type) {
        if (file == null || file.isEmpty()) {
            throw new AppException("File is empty or missing", HttpStatus.BAD_REQUEST);
        }
        String contentType = file.getContentType();
        if (contentType == null || !allowedTypes.contains(contentType)) {
            throw new AppException(
                    "Invalid " + type + " type: " + contentType + ". Allowed: " + allowedTypes,
                    HttpStatus.BAD_REQUEST
            );
        }
    }
}
