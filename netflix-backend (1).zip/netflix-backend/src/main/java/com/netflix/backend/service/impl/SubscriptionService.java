package com.netflix.backend.service.impl;

import com.netflix.backend.dto.response.ResponseDTOs.PlanInfo;
import com.netflix.backend.dto.response.ResponseDTOs.SubscriptionResponse;
import com.netflix.backend.entity.Subscription;
import com.netflix.backend.entity.User;
import com.netflix.backend.exception.AppException;
import com.netflix.backend.repository.SubscriptionRepository;
import com.netflix.backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SubscriptionService {

    private final SubscriptionRepository subscriptionRepository;
    private final UserRepository userRepository;

    // ── Get Plans ─────────────────────────────────────────────────────────

    public List<PlanInfo> getAvailablePlans() {
        return List.of(
                PlanInfo.builder()
                        .name("FREE")
                        .priceInr(0)
                        .description("Basic access with limited features")
                        .features(List.of(
                                "Browse all content",
                                "Watch free videos",
                                "Basic video quality (480p)",
                                "Watch history tracking"
                        ))
                        .popular(false)
                        .build(),

                PlanInfo.builder()
                        .name("STANDARD")
                        .priceInr(299)
                        .description("Great for individuals")
                        .features(List.of(
                                "All FREE features",
                                "HD streaming (1080p)",
                                "Access to premium content",
                                "Personalized recommendations",
                                "Download for offline viewing",
                                "No ads"
                        ))
                        .popular(true)
                        .build(),

                PlanInfo.builder()
                        .name("PREMIUM")
                        .priceInr(499)
                        .description("Best for families and enthusiasts")
                        .features(List.of(
                                "All STANDARD features",
                                "4K Ultra HD streaming",
                                "Exclusive premium content",
                                "Priority customer support",
                                "Simultaneous streams on 4 devices",
                                "Spatial audio"
                        ))
                        .popular(false)
                        .build()
        );
    }

    // ── Get Subscription Status ───────────────────────────────────────────

    public SubscriptionResponse getStatus(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        Subscription sub = subscriptionRepository.findByUserId(user.getId())
                .orElseThrow(() -> new AppException("Subscription record not found", HttpStatus.NOT_FOUND));
        return SubscriptionResponse.from(sub);
    }

    // ── Subscribe / Upgrade ───────────────────────────────────────────────

    @Transactional
    public SubscriptionResponse subscribe(String userEmail, String planName) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        Subscription.Plan plan;
        try {
            plan = Subscription.Plan.valueOf(planName.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new AppException("Invalid plan: " + planName + ". Valid plans: FREE, STANDARD, PREMIUM", HttpStatus.BAD_REQUEST);
        }

        Subscription sub = subscriptionRepository.findByUserId(user.getId())
                .orElse(Subscription.builder().user(user).build());

        sub.setPlan(plan);
        sub.setStatus(Subscription.Status.ACTIVE);
        sub.setStartDate(LocalDateTime.now());

        // Set end date based on plan
        if (plan == Subscription.Plan.FREE) {
            sub.setEndDate(null);
            user.setRole(User.Role.USER);
        } else {
            sub.setEndDate(LocalDateTime.now().plusMonths(1));
            user.setRole(User.Role.PREMIUM_USER);
        }

        userRepository.save(user);
        Subscription saved = subscriptionRepository.save(sub);

        log.info("User {} subscribed to plan: {}", userEmail, plan);
        return SubscriptionResponse.from(saved);
    }

    // ── Cancel ────────────────────────────────────────────────────────────

    @Transactional
    public SubscriptionResponse cancel(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        Subscription sub = subscriptionRepository.findByUserId(user.getId())
                .orElseThrow(() -> new AppException("Subscription not found", HttpStatus.NOT_FOUND));

        if (sub.getPlan() == Subscription.Plan.FREE) {
            throw new AppException("Free plan cannot be cancelled", HttpStatus.BAD_REQUEST);
        }
        if (sub.getStatus() == Subscription.Status.CANCELLED) {
            throw new AppException("Subscription is already cancelled", HttpStatus.BAD_REQUEST);
        }

        sub.setStatus(Subscription.Status.CANCELLED);
        subscriptionRepository.save(sub);

        log.info("User {} cancelled subscription", userEmail);
        return SubscriptionResponse.from(sub);
    }

    // ── Scheduled: Auto-expire subscriptions ─────────────────────────────

    @Scheduled(cron = "0 0 2 * * ?") // Run at 2 AM daily
    @Transactional
    public void expireSubscriptions() {
        List<Subscription> expired = subscriptionRepository.findExpiredSubscriptions(LocalDateTime.now());
        if (!expired.isEmpty()) {
            expired.forEach(sub -> {
                sub.setStatus(Subscription.Status.EXPIRED);
                sub.getUser().setRole(User.Role.USER);
                userRepository.save(sub.getUser());
            });
            subscriptionRepository.saveAll(expired);
            log.info("Expired {} subscriptions", expired.size());
        }
    }
}
