package com.netflix.backend.service.impl;

import com.netflix.backend.dto.request.VideoRequest;
import com.netflix.backend.dto.response.ResponseDTOs.*;
import com.netflix.backend.entity.*;
import com.netflix.backend.exception.AppException;
import com.netflix.backend.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class VideoService {

    private final VideoRepository videoRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final LikeRepository likeRepository;
    private final WatchHistoryRepository watchHistoryRepository;
    private final SearchHistoryRepository searchHistoryRepository;
    private final SubscriptionRepository subscriptionRepository;

    private static final int MAX_SEARCH_HISTORY = 20;

    // ── Get All Videos (paginated) ────────────────────────────────────────

    public Page<VideoResponse> getAllVideos(int page, int size, Long categoryId) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<Video> videos = (categoryId != null)
                ? videoRepository.findByCategoryId(categoryId, pageable)
                : videoRepository.findAll(pageable);
        return videos.map(VideoResponse::from);
    }

    // ── Get Single Video ──────────────────────────────────────────────────

    public VideoResponse getVideoById(Long id, String userEmail) {
        Video video = videoRepository.findById(id)
                .orElseThrow(() -> new AppException("Video not found with id: " + id, HttpStatus.NOT_FOUND));

        // Premium check
        if (video.isPremium() && userEmail != null) {
            checkPremiumAccess(userEmail);
        } else if (video.isPremium()) {
            throw new AppException("This is premium content. Please subscribe to access.", HttpStatus.FORBIDDEN);
        }

        VideoResponse response = VideoResponse.from(video);
        response.setLikeCount(likeRepository.countByVideoId(id));

        // Enrich with user-specific data
        if (userEmail != null) {
            userRepository.findByEmail(userEmail).ifPresent(user -> {
                response.setLiked(likeRepository.existsByUserIdAndVideoId(user.getId(), id));
                watchHistoryRepository.findByUserIdAndVideoId(user.getId(), id).ifPresent(wh -> {
                    response.setWatchProgress(wh.getProgressSeconds());
                    response.setWatched(true);
                });
            });
        }

        return response;
    }

    // ── Featured Videos ───────────────────────────────────────────────────

    public List<VideoResponse> getFeaturedVideos(int limit) {
        return videoRepository.findFeaturedVideos(PageRequest.of(0, limit))
                .stream().map(VideoResponse::from).collect(Collectors.toList());
    }

    // ── Trending Videos ───────────────────────────────────────────────────

    public List<VideoResponse> getTrendingVideos(int limit) {
        return videoRepository.findTrendingVideos(PageRequest.of(0, limit))
                .stream().map(VideoResponse::from).collect(Collectors.toList());
    }

    // ── New Releases ──────────────────────────────────────────────────────

    public List<VideoResponse> getNewReleases(int limit) {
        return videoRepository.findNewReleases(PageRequest.of(0, limit))
                .stream().map(VideoResponse::from).collect(Collectors.toList());
    }

    // ── Search ────────────────────────────────────────────────────────────

    @Transactional
    public Page<VideoResponse> searchVideos(String query, int page, int size, String userEmail) {
        Pageable pageable = PageRequest.of(page, size);
        Page<VideoResponse> results = videoRepository.searchVideos(query, pageable).map(VideoResponse::from);

        // Save search history asynchronously
        if (userEmail != null && query != null && !query.isBlank()) {
            saveSearchHistoryAsync(userEmail, query.trim());
        }

        return results;
    }

    // ── Recommendations ───────────────────────────────────────────────────

    public List<VideoResponse> getRecommendations(String userEmail, int limit) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        List<VideoResponse> recs = videoRepository
                .findRecommendations(user.getId(), PageRequest.of(0, limit))
                .stream().map(VideoResponse::from).collect(Collectors.toList());

        // If not enough recommendations, pad with trending
        if (recs.size() < limit) {
            List<VideoResponse> trending = videoRepository
                    .findTrendingVideos(PageRequest.of(0, limit))
                    .stream().map(VideoResponse::from).collect(Collectors.toList());
            trending.removeIf(t -> recs.stream().anyMatch(r -> r.getId().equals(t.getId())));
            recs.addAll(trending.subList(0, Math.min(limit - recs.size(), trending.size())));
        }

        return recs;
    }

    // ── Increment View Count ──────────────────────────────────────────────

    @Async("taskExecutor")
    @Transactional
    public void incrementViewCount(Long videoId) {
        videoRepository.incrementViewCount(videoId);
    }

    // ── Toggle Like ───────────────────────────────────────────────────────

    @Transactional
    public boolean toggleLike(Long videoId, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        Video video = videoRepository.findById(videoId)
                .orElseThrow(() -> new AppException("Video not found", HttpStatus.NOT_FOUND));

        return likeRepository.findByUserIdAndVideoId(user.getId(), videoId).map(like -> {
            likeRepository.delete(like);
            return false; // unliked
        }).orElseGet(() -> {
            likeRepository.save(Like.builder().user(user).video(video).build());
            return true; // liked
        });
    }

    // ── Get Liked Videos ──────────────────────────────────────────────────

    public List<VideoResponse> getLikedVideos(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        return likeRepository.findLikedVideosByUserId(user.getId(), PageRequest.of(0, 50))
                .stream().map(v -> {
                    VideoResponse r = VideoResponse.from(v);
                    r.setLiked(true);
                    return r;
                }).collect(Collectors.toList());
    }

    // ── Save / Update Watch Progress ──────────────────────────────────────

    @Transactional
    public void saveWatchProgress(VideoRequest.Progress request, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        Video video = videoRepository.findById(request.getVideoId())
                .orElseThrow(() -> new AppException("Video not found", HttpStatus.NOT_FOUND));

        WatchHistory wh = watchHistoryRepository
                .findByUserIdAndVideoId(user.getId(), request.getVideoId())
                .orElse(WatchHistory.builder().user(user).video(video).build());

        wh.setProgressSeconds(request.getProgressSeconds());

        // Mark complete if watched >= 90%
        if (video.getDurationSeconds() != null && video.getDurationSeconds() > 0) {
            double pct = (double) request.getProgressSeconds() / video.getDurationSeconds();
            wh.setCompleted(pct >= 0.9);
        }

        watchHistoryRepository.save(wh);
    }

    // ── Get Watch History ─────────────────────────────────────────────────

    public List<WatchHistoryResponse> getWatchHistory(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));

        return watchHistoryRepository
                .findByUserIdOrderByWatchedAtDesc(user.getId(), PageRequest.of(0, 30))
                .stream()
                .map(wh -> {
                    int duration = wh.getVideo().getDurationSeconds() != null
                            ? wh.getVideo().getDurationSeconds() : 0;
                    int progress = wh.getProgressSeconds();
                    int pct = (duration > 0) ? (int) ((double) progress / duration * 100) : 0;

                    return WatchHistoryResponse.builder()
                            .id(wh.getId())
                            .videoId(wh.getVideo().getId())
                            .title(wh.getVideo().getTitle())
                            .thumbnailUrl(wh.getVideo().getThumbnailUrl())
                            .progressSeconds(progress)
                            .durationSeconds(duration)
                            .completed(wh.isCompleted())
                            .progressPercentage(Math.min(pct, 100))
                            .watchedAt(wh.getWatchedAt())
                            .build();
                })
                .collect(Collectors.toList());
    }

    // ── Remove from Watch History ─────────────────────────────────────────

    @Transactional
    public void removeFromHistory(Long videoId, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        watchHistoryRepository.deleteByUserIdAndVideoId(user.getId(), videoId);
    }

    // ── Get Search History ────────────────────────────────────────────────

    public List<SearchHistoryResponse> getSearchHistory(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        return searchHistoryRepository
                .findByUserIdOrderBySearchedAtDesc(user.getId(), PageRequest.of(0, 20))
                .stream()
                .map(sh -> SearchHistoryResponse.builder()
                        .id(sh.getId())
                        .query(sh.getQuery())
                        .searchedAt(sh.getSearchedAt())
                        .build())
                .collect(Collectors.toList());
    }

    // ── Clear Search History ──────────────────────────────────────────────

    @Transactional
    public void clearSearchHistory(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        searchHistoryRepository.deleteAllByUserId(user.getId());
    }

    // ── Private Helpers ───────────────────────────────────────────────────

    private void checkPremiumAccess(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new AppException("User not found", HttpStatus.NOT_FOUND));
        subscriptionRepository.findByUserId(user.getId())
                .filter(s -> s.getPlan() != Subscription.Plan.FREE
                        && s.getStatus() == Subscription.Status.ACTIVE)
                .orElseThrow(() -> new AppException(
                        "Premium subscription required. Please upgrade your plan.", HttpStatus.FORBIDDEN));
    }

    @Async("taskExecutor")
    @Transactional
    public void saveSearchHistoryAsync(String userEmail, String query) {
        userRepository.findByEmail(userEmail).ifPresent(user -> {
            long count = searchHistoryRepository.countByUserId(user.getId());
            if (count >= MAX_SEARCH_HISTORY) {
                List<SearchHistory> oldest = searchHistoryRepository
                        .findOldestByUserId(user.getId(), PageRequest.of(0, 1));
                if (!oldest.isEmpty()) {
                    searchHistoryRepository.delete(oldest.get(0));
                }
            }
            SearchHistory sh = SearchHistory.builder()
                    .user(user)
                    .query(query)
                    .build();
            searchHistoryRepository.save(sh);
        });
    }
}
