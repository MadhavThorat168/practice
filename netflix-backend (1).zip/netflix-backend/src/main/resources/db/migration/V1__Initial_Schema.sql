-- ============================================================
-- Netflix DB - V1 Initial Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id                  BIGINT          AUTO_INCREMENT PRIMARY KEY,
    email               VARCHAR(255)    NOT NULL UNIQUE,
    password            VARCHAR(255)    NOT NULL,
    display_name        VARCHAR(100),
    profile_picture     VARCHAR(500),
    role                ENUM('USER','PREMIUM_USER','ADMIN') NOT NULL DEFAULT 'USER',
    refresh_token       TEXT,
    is_enabled          BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================

CREATE TABLE IF NOT EXISTS categories (
    id              BIGINT          AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)    NOT NULL UNIQUE,
    slug            VARCHAR(100)    NOT NULL UNIQUE,
    description     TEXT,
    thumbnail_url   VARCHAR(500),
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_categories_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================

CREATE TABLE IF NOT EXISTS videos (
    id                  BIGINT          AUTO_INCREMENT PRIMARY KEY,
    title               VARCHAR(255)    NOT NULL,
    description         TEXT,
    video_url           VARCHAR(500)    NOT NULL,
    thumbnail_url       VARCHAR(500),
    trailer_url         VARCHAR(500),
    duration_seconds    INT             DEFAULT 0,
    release_year        INT,
    is_premium          BOOLEAN         NOT NULL DEFAULT FALSE,
    is_featured         BOOLEAN         NOT NULL DEFAULT FALSE,
    view_count          BIGINT          NOT NULL DEFAULT 0,
    category_id         BIGINT          NOT NULL,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    INDEX idx_videos_category (category_id),
    INDEX idx_videos_featured (is_featured),
    INDEX idx_videos_premium (is_premium),
    INDEX idx_videos_views (view_count DESC),
    FULLTEXT INDEX ft_videos_search (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================

CREATE TABLE IF NOT EXISTS subscriptions (
    id          BIGINT      AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT      NOT NULL UNIQUE,
    plan        ENUM('FREE','STANDARD','PREMIUM') NOT NULL DEFAULT 'FREE',
    status      ENUM('ACTIVE','CANCELLED','EXPIRED') NOT NULL DEFAULT 'ACTIVE',
    start_date  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    end_date    DATETIME,
    created_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_subscriptions_user (user_id),
    INDEX idx_subscriptions_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================

CREATE TABLE IF NOT EXISTS watch_history (
    id                  BIGINT      AUTO_INCREMENT PRIMARY KEY,
    user_id             BIGINT      NOT NULL,
    video_id            BIGINT      NOT NULL,
    progress_seconds    INT         NOT NULL DEFAULT 0,
    completed           BOOLEAN     NOT NULL DEFAULT FALSE,
    watched_at          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    UNIQUE KEY uq_watch_history (user_id, video_id),
    INDEX idx_watch_user_date (user_id, watched_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================

CREATE TABLE IF NOT EXISTS likes (
    id          BIGINT      AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT      NOT NULL,
    video_id    BIGINT      NOT NULL,
    created_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    UNIQUE KEY uq_likes (user_id, video_id),
    INDEX idx_likes_user (user_id),
    INDEX idx_likes_video (video_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================

CREATE TABLE IF NOT EXISTS search_history (
    id          BIGINT      AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT      NOT NULL,
    query       VARCHAR(500) NOT NULL,
    searched_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_search_user_date (user_id, searched_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Default Admin user: admin@netflix.com / Admin@123
INSERT INTO users (email, password, display_name, role) VALUES
('admin@netflix.com', '$2a$12$RIBMgDdCWGP2g2LiOcAnpOqmO8i0ZLwnJcJ3Mg7t8.OiHDvOhFo9C', 'Netflix Admin', 'ADMIN')
ON DUPLICATE KEY UPDATE id = id;

-- Seed categories
INSERT INTO categories (name, slug, description) VALUES
('Action',      'action',      'High-octane action movies and series'),
('Drama',       'drama',       'Compelling dramas and storytelling'),
('Comedy',      'comedy',      'Laugh-out-loud comedies for everyone'),
('Thriller',    'thriller',    'Edge-of-your-seat thrillers'),
('Sci-Fi',      'sci-fi',      'Science fiction and futuristic worlds'),
('Horror',      'horror',      'Horror, supernatural and suspense content'),
('Documentary', 'documentary', 'Real-world documentaries and stories'),
('Romance',     'romance',     'Love stories and romantic films'),
('Animation',   'animation',   'Animated movies and shows for all ages'),
('Crime',       'crime',       'Crime dramas, heists and mysteries')
ON DUPLICATE KEY UPDATE id = id;

-- Seed admin subscription
INSERT INTO subscriptions (user_id, plan, status, end_date)
SELECT u.id, 'PREMIUM', 'ACTIVE', DATE_ADD(NOW(), INTERVAL 1 YEAR)
FROM users u WHERE u.email = 'admin@netflix.com'
ON DUPLICATE KEY UPDATE subscriptions.plan = subscriptions.plan;
